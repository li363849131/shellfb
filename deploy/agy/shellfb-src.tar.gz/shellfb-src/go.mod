module github.com/li363849131/shellfb

go 1.26.3

require (
	github.com/creack/pty v1.1.24
	github.com/golang-jwt/jwt/v5 v5.3.1
	github.com/gorilla/websocket v1.5.3
	golang.org/x/crypto v0.51.0
	gopkg.in/yaml.v3 v3.0.1
)

require (
	github.com/UserExistsError/conpty v0.1.4 // indirect
	golang.org/x/net v0.53.0 // indirect
	golang.org/x/sys v0.44.0 // indirect
	golang.org/x/text v0.37.0 // indirect
)
